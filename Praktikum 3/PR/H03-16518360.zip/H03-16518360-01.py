# NIM/Nama  : 16518360/Ilham Syahid S
# Tanggal   : 7 Oktober 2018
# Deskripsi : Pasangan Komposit

def Komposit(x): #Fungsi apakah x adalah komposit
    isTrue = False
    i = 2
    while x > i and not isTrue: # Pertama akan masuk while
        if x % i == 0: # Jika ada yang sisa bagi 0, maka itu adalah komposit, jika bersisa hingga x-1 maka bil. itu adalah prima
            isTrue = True # Jika diketahui bil. komposit maka setelah putaran selanjutnya tidak akan masuk while
        i += 1 
    return isTrue

def PasKom(a, b): #Fungsi apakah pasangan komposit
    if Komposit(a) and Komposit(b) and Komposit(a+b): # jika a, b, a+b lulus fungsi Komposit
        return True # maka dinyatakan pasangan komposit

#input
a = int(input("Masukkan A: "))      
b = int(input("Masukkan B: "))      

#output
print("Pasangan bilangan komposit:")
for i in range(a, b+1): # Cek bil. dari a hingga b  
    for j in range(a, b+1):
        if PasKom(i,j) and i < j: # Cek bil. tersebut pasangan komposit dan yang pertama harus lebih kecil dari yang kedua 
            print(i, j) #print