#NIM/Nama	: 16518360/Ilham Syahid S
#Tanggal	: 31 Oktober 2018
#Deskripsi	: 

import pandas as pd
import matplotlib
matplotlib.use('agg')
import matplotlib.pyplot as plt

# 1. Banyaknya data
df = pd.read_csv('stei-b.csv')
print(len(df))

# 2. Pie chart banyaknya mahasiswa tiap fakultas.
df1 = df['fakultas'].value_counts()
df1.plot(kind='pie')
plt.savefig("Soal2.png", bbox_inches="tight") #Tdak bisa show()

# 3. Pie chart banyaknya mahasiswa FTSL berdasarkan tingkat
df2 = df.loc[df['fakultas'] == 'FTSL']
s3 = df2['tingkat'].value_counts()
s3.plot(kind='pie')
plt.savefig("Soal3.png", bbox_inches="tight") #Tdak bisa show()

# 4.  Histogram dengan IP sebagai sumbu x dan jumlah mahasiswa sebagai sumbu y, gunakan pertambahan 0.5
df[['ip']].plot(kind='hist',bins=[0,0.5,1,1.5,2,2.5,3,3.5,4], rwidth=0.8)
plt.savefig("Soal4.png", bbox_inches='tight')

# 5. Berdasar plot sebelumnya, range ip mana yang paling banyak diperoleh?
print('3.0 - 3.5') #3.0 - 3.5

# 6. Stacked bar chart dengan tingkat sebagai sumbu x dan jumlah mahasiswa tiap fakultas sebagai stacked sumbu y

#df.plot(kind = "bar", x =df["tingkat"], stacked = True)
#plt.savefig("Soal6.png", bbox_inches='tight')

# 7. Berdasar plot sebelumnya, angkatan ke berapa STEI jumlah mahasiswanya paling sedikit?
df7 = df.loc[df['fakultas'] == 'STEI']
df7 = df7['tingkat'].value_counts()
print(df7) #2017

# 8. Line chart dengan tingkat sebagai sumbu x dan jumlah mahasiswa sebagai sumbu y
df.plot(kind = "line", x ="tingkat", y='fakultas', stacked = True)
plt.savefig("Soal8.png", bbox_inches='tight')

#9.  Line chart seperti soal sebelumnya, namun terdapat 4 garis, masing-masing untuk tiap fakultas.
df.plot(kind = "line", x ="fakultas", stacked = True)
plt.savefig("Soal9.png", bbox_inches='tight')

#10.  Berdasar plot sebelumnya, fakultas manakah yang jumlah mahasiswanya terus bertambah?

#11.  Berdasar plot sebelumnya, fakultas manakah yang jumlah mahasiswanya terus berkurang?
